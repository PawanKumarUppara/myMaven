package com.hellospring.dao;

import java.util.List;

import com.hellospring.Product;

public interface ProductDaoInt {
void addProduct(Product product);
Product getProductById(int id);
List<Product> getAllProducts();
void deleteProduct(int id);
}
